# 这是 Pmw库 的部分
# http://pmw.sourceforge.net/
# https://pypi.org/project/Pmw/
# 由于原库不方便打包，于是将代码内置于 Umi-OCR 工程中
# 版权归原作者所有

# C:\Coding\Python\Python308\Lib\site-packages\Pmw\Pmw_2_1_1\lib
